class ProviderExhausted(
    Exception
):
    pass